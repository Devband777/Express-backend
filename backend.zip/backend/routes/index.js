import { 
  UsersController,
  DrivesController,
  FoldersController,
  FilesController,
} from '../controllers';

import {
  arweaveAddress
} from '../api'

import {
  auth
} from '../middleware/auth';

const { Router } = require('express')

const router = Router();

/* GET index page. */
router.post('/', (req, res) => {
  res.json({
    msg: 'Ardrive backend server works',
    address: arweaveAddress,
  });
});

/** User routes */
router.post('/users/register', auth, UsersController.register);
router.post('/users/getBalance', auth, UsersController.getBalance);
router.post('/users/deposit', auth, UsersController.deposit);

/** Drive routes */
router.post('/drives/createDrive', auth, DrivesController.createDrive);
router.post('/drives/listDrive', auth, DrivesController.listDrive);
router.post('/drives/getDriveKey', auth, DrivesController.getDriveKey);

/** Folder routes */
router.post('/folders/createFolder', auth, FoldersController.createFolder);
router.post('/folders/renameFolder', auth, FoldersController.renameFolder);
router.post('/folders/moveFolder', auth, FoldersController.moveFolder);
router.post('/folders/listFolder', auth, FoldersController.listFolder);

/** File routes */
router.post('/files/prepareFiles', auth, FilesController.prepareFiles);
router.post('/files/uploadFile', auth, FilesController.uploadFile);
router.post('/files/renameFile', auth, FilesController.renameFile);
router.post('/files/moveFile', auth, FilesController.moveFile);
module.exports = router;
