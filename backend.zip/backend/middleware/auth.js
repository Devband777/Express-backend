import { magic } from '../helper/magic';

export const auth = async (req, res, next) => {
  const token = req.headers.authorization || null;

  if(!token) {
    res.status(401).json({
      status: false,
      message: 'Unauthorized'
    });
  }

  const metadata = await magic.users.getMetadataByToken(token);
  // res.status(200).json({
  //   message: metadata
  // })
  if(!metadata.email || !metadata.issuer) {
    res.status(400).json({
      status: false,
      message: 'wrong token'
    });
  }

  // for local test
  // const metadata = {
  //   email: 'lifechain@mail.io',
  // }

  req.user = metadata;
  next();
}