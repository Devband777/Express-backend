import mongoose from 'mongoose';

const { Schema } = mongoose;

const thumbSchema = new Schema({
  id: {
    type: String,
    unique: true,
  },
  url: {
    type: String,
  }
});

export default mongoose.model('Thumb', thumbSchema);
