import mongoose from 'mongoose';

const { Schema } = mongoose;

const userSchema = new Schema({
  email: {
    type: String,
    unique: true,
    lowercase: true
  },
  // email_verified: { type: Boolean, default: false },
  deleted: {
    type: String,
    default: 'no'
  },
  role: {
    type: String,
    default: 'user'
  },
  created_at: {
    type: Date,
    default: Date.now
  },
  updated_at: {
    type: Date,
    default: Date.now
  },
  privateKey: {
    type: Object,
    default: null
  },
  password: {
    type: String,
  },
});

export default mongoose.model('User', userSchema);
