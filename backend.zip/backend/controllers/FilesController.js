import {
  readJWKFile,
  arDriveFactory,
} from 'ardrive-core-js';
import arweave from '../api';
import shell from 'shelljs';
import multer from 'multer';
import fs from 'fs';
import path, {
  resolve
} from 'path';
import {
  arweaveAddress
} from '../api'
import * as conf from '../config.json';
import User from '../models/UsersModel';
import Thumb from '../models/ThumbsModel';
import validator from '../helper/validate'

const environment = process.env.NODE_ENV || 'development';
const config = conf[environment];

const renameFile = async (req, res) => {
  // Validate
  const validationRule = {
    "fileId": "required|string",
    "newFileName": "required|string",
  };

  const {
    email
  } = req.user;

  const {
    fileId,
    newFileName,
    driveKey,
    type = 'public',
  } = req.body;

  if(type === 'private') {
    validationRule.driveKey = "required|string"
  }

  await validator(req.body, validationRule, {}, async (err, status) => {
    if(!status) {
      res
        .status(412)
        .send({
          status: false,
          message: 'Validation failed',
          data: err
        });
    } else {
      const existUser = await User.findOne({email: email});
      if(!!existUser) {
        const myWallet = readJWKFile(`./wallet/${existUser.password}.json`);
        const arDrive = arDriveFactory({
          wallet: myWallet,
          arweave: arweave,
        })
        let result;
        if(type === 'public') {
          const {
            stdout,
            stderr,
            code
          } = await shell.exec(`npx ardrive rename-file --file-id ${fileId} --file-name ${newFileName} -w ./wallet/${existUser.password}.json --gateway ${arweaveAddress}`);
          if(code === 1)
            res.json({
              status: false,
              msg: stdout.replace("\n", "")
            })
          
        result = JSON.parse(stdout);
        } else if(type === 'private') {
          const {
            stdout,
            stderr,
            code
          } = await shell.exec(`npx ardrive rename-file --file-id ${fileId} --file-name ${newFileName} -w ./wallet/${existUser.password}.json --gateway ${arweaveAddress} --drive-key ${driveKey}`);
          if(code === 1)
            res.json({
              status: false,
              msg: stdout.replace("\n", "")
            })
          
          result = JSON.parse(stdout);
        } else {
          res.json({
            status: false,
            msg: 'You can select public or private for folder type'
          });
        }
        res.json({
          status: true,
          msg: `Successfully ${type} file uploaded`,
          data: result
        })
      } else {
        res.json({
          status: false,
          message: 'User not found'
        });
      }
    }
  })
  // end
  const {
    privateKey,
  } = await User.findOne({email});
  const myWallet = readJWKFile(privateKey);
  const arDrive = arDriveFactory({ wallet: myWallet });
  let createFolderResult = {};
  if(type === 'public') {
    createFolderResult = await arDrive.createPublicFolder({ folderName, parentFolderId });
  }
  if(type === 'private') {
    createFolderResult = await arDrive.createPrivateFolder({ folderName, driveKey, parentFolderId });
  }
  res.json({
    status: true,
    data: createFolderResult
  })
};
//npx ardrive upload-file --wallet-file /path/to/my/wallet.json --parent-folder-id "f0c58c11-430c-4383-8e54-4d864cc7e927" --local-path ./helloworld.txt --dest-file-name "ode_to_ardrive.txt"
const uploadFile = async (req, res) => {
  // Validate
  const validationRule = {
    "parentFolderId": "required|string",
    "tempFolder": "required|string",
  };

  const {
    email
  } = req.user;

  const {
    tempFolder,
    parentFolderId,
    driveKey,
    type = 'public',
  } = req.body;

  if(type === 'private') {
    validationRule.driveKey = "required|string"
  }

  await validator(req.body, validationRule, {}, async (err, status) => {
    if(!status) {
      res
        .status(412)
        .send({
          status: false,
          message: 'Validation failed',
          data: err
        });
    } else {
      const existUser = await User.findOne({email: email});
      if(!!existUser) {
        const myWallet = readJWKFile(`./wallet/${existUser.password}.json`);
        const arDrive = arDriveFactory({
          wallet: myWallet,
          arweave: arweave,
        })
        let result;
        // get file lists
        let files_list_arr = [];
        fs.readdirSync(tempFolder).forEach(file => {  
          files_list_arr.push(tempFolder+'/'+file);
        });
        console.log('###', files_list_arr)
        let files_list_string = "";
        for (let i = 0; i < files_list_arr.length; i++) {
          files_list_string += (`"${files_list_arr[i]}" `);
        }
        console.log('###', files_list_string)
        // end
        if(type === 'public') {
          const {
            stdout,
            stderr,
            code
          } = await shell.exec(`npx ardrive upload-file --replace --local-paths ${files_list_string} --parent-folder-id ${parentFolderId} -w ./wallet/${existUser.password}.json --gateway ${arweaveAddress}`);
          if(code === 1)
            res.json({
              status: false,
              msg: stdout.replace("\n", "")
            })
          
        result = JSON.parse(stdout);
        } else if(type === 'private') {
          const {
            stdout,
            stderr,
            code
          } = await shell.exec(`npx ardrive upload-file --replace --local-paths ${files_list_string} --parent-folder-id ${parentFolderId} -w ./wallet/${existUser.password}.json --gateway ${arweaveAddress} --drive-key ${driveKey}`);
          if(code === 1)
            res.json({
              status: false,
              msg: stdout.replace("\n", "")
            })
          
          result = JSON.parse(stdout);
        } else {
          res.json({
            status: false,
            msg: 'You can select public or private for folder type'
          });
        }

        // send image files from temp folder to thumb folder
        console.log('start............')

        await result.created.map(async item => {
          if(item.type === 'file') {
            let fileExt = item.entityName.split('.').pop();
            console.log(item)
            if(fileExt === 'jpg' || fileExt === 'png') {
              console.log(tempFolder.split('/')[2] + '/' + item.entityName)
              const thumb = new Thumb;
              thumb.id = item.dataTxId;
              thumb.url = tempFolder.split('/')[2] + '/' + item.entityName;
              await thumb.save();
            }
          }
        })
        console.log('end............')
        // delete tempFolder
        // fs.rm(tempFolder, {recursive: true, force: true}, err => {
        //   if(err) {
        //     throw err;
        //   }

          res.json({
            status: true,
            msg: `Successfully ${type} files uploaded`,
            data: result
          })
        // });
        // end
      } else {
        res.json({
          status: false,
          message: 'User not found'
        });
      }
    }
  })
  // end
};

const sendFiles = async (req, res) => {
  const {
    email
  } = req.user;

  
};

const prepareFiles = async (req, res, next) => {
  const {
    email
  } = req.user;
  const existUser = await User.findOne({email: email});
  // middleware
  const folderName = new Date().valueOf();
  const DIR = './upload/'+folderName;
  
  if(!fs.existsSync(DIR)) {
    fs.mkdirSync(DIR, { recursive: true });
  }

  const storage = multer.diskStorage({
      destination: (req, file, cb) => {
          cb(null, DIR);
      },
      filename: (req, file, cb) => {
          const fileName = file.originalname;
          cb(null, fileName)
      }
  });
  var upload = multer({
    storage: storage,
    fileFilter: (req, file, cb) => {
      cb(null, true);
    }
  });
  // end

  upload.array('files')(req, res, async () => {
    console.log(req.files);
    console.log(req.user);
    console.log(req.body.parentFolderId);
    // predict the AR value to upload data 
    // const {
    //   stdout,
    //   stderr,
    //   code
    // } = await shell.exec(`npx ardrive upload-file --replace --local-path ${DIR} --parent-folder-id ${req.body.parentFolderId} -w ./wallet/${existUser.password}.json --gateway ${arweaveAddress} --dry-run`);
    // if(code === 1)
    //   res.json({
    //     status: false,
    //     msg: stdout.replace("\n", "")
    //   })
    
    // let result = JSON.parse(stdout);
    // end
    res.json({ 
      message: "Successfully uploaded files",
      status: true,
      data: {
        folder: DIR,
        files: req.files,
        //result: result,
      }
    });  
  })
};

const moveFile = async (req, res) => {
  // Validate
  const validationRule = {
    "fileId": "required|string",
    "parentFolderId": "required|string",
  };

  const {
    email
  } = req.user;

  const {
    parentFolderId,
    fileId,
    driveKey,
    type = 'public',
  } = req.body;

  if(type === 'private') {
    validationRule.driveKey = "required|string"
  }

  await validator(req.body, validationRule, {}, async (err, status) => {
    if(!status) {
      res
        .status(412)
        .send({
          status: false,
          message: 'Validation failed',
          data: err
        });
    } else {
      const existUser = await User.findOne({email: email});
      if(!!existUser) {
        const myWallet = readJWKFile(`./wallet/${existUser.password}.json`);
        const arDrive = arDriveFactory({
          wallet: myWallet,
          arweave: arweave,
        })
        let result;
        if(type === 'public') {
          const {
            stdout,
            stderr,
            code
          } = await shell.exec(`npx ardrive move-file --file-id ${fileId} --parent-folder-id ${parentFolderId} --wallet-file ./wallet/${existUser.password}.json --gateway ${arweaveAddress}`);
          if(code === 1)
            res.json({
              status: false,
              msg: stdout.replace("\n", "")
            })
          
        result = JSON.parse(stdout);
        } else if(type === 'private') {
          const {
            stdout,
            stderr,
            code
          } = await shell.exec(`npx ardrive move-file --file-id ${fileId} --parent-folder-id ${parentFolderId} --wallet-file ./wallet/${existUser.password}.json --gateway ${arweaveAddress} --drive-key ${driveKey}`);
          if(code === 1)
            res.json({
              status: false,
              msg: stdout.replace("\n", "")
            })
          
          result = JSON.parse(stdout);
        } else {
          res.json({
            status: false,
            msg: 'You can select public or private for folder type'
          });
        }
        res.json({
          status: true,
          msg: `Successfully ${type} file moved`,
          data: result
        })
      } else {
        res.json({
          status: false,
          message: 'User not found'
        });
      }
    }
  })
  // end
  const {
    privateKey,
  } = await User.findOne({email});
  const myWallet = readJWKFile(privateKey);
  const arDrive = arDriveFactory({ wallet: myWallet });
  let createFolderResult = {};
  if(type === 'public') {
    createFolderResult = await arDrive.createPublicFolder({ folderName, parentFolderId });
  }
  if(type === 'private') {
    createFolderResult = await arDrive.createPrivateFolder({ folderName, driveKey, parentFolderId });
  }
  res.json({
    status: true,
    data: createFolderResult
  })
};

const FilesController = {
  sendFiles,
  uploadFile,
  renameFile,
  moveFile,
  prepareFiles,
};

export default FilesController;