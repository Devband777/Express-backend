import {
  readJWKFile,
  arDriveFactory,
} from 'ardrive-core-js';
import fs from 'fs';
import shell from 'shelljs';
import arweave from '../api'
import path, {
  resolve
} from 'path';
import {
  arweaveAddress
} from '../api'
import * as conf from '../config.json';
import User from '../models/UsersModel';
import validator from '../helper/validate'

const environment = process.env.NODE_ENV || 'development';
const config = conf[environment];
const platformWallet = 'ZhdWf-PvoXjosmaqGMODPo2T-bbfLVLEzgq9RS-grUs';

const getBalance = async (req, res) => {
  // Validate
  const {
    email
  } = req.user;
  
  const existUser = await User.findOne({email: email});
  if(!!existUser) {
    const walletAddress = await arweave.wallets.jwkToAddress(existUser.privateKey);
    console.log(walletAddress)
    const balance = await arweave.wallets.getBalance(walletAddress); // winston
    console.log(balance)
    let ar = await arweave.ar.winstonToAr(balance); // winston to ar
    console.log(ar)
    res.json({
      status: true,
      message: 'Wallet balance',
      data: {
        walletAddress,
        balance: ar,
      }
    });
  } else {
    res.json({
      status: false,
      message: 'User not found'
    });
  }
}

const register = async (req, res) => {
    // Validate
    const {
      email
    } = req.user;

    const existUser = await User.findOne({email: email});
    console.log(email, existUser);
    if(!!existUser) {
      const balance = await arweave.wallets.getBalance(existUser.password); // winston
      res.json({
        status: true,
        balance: balance,
        message: existUser
      });
    } else {
      const privateKey = await arweave.wallets.generate();
      const newUser = new User;
      newUser.email = email;
      newUser.privateKey = privateKey;
      const password = await arweave.wallets.jwkToAddress(privateKey);
      newUser.password = password;
      const savedUser = await newUser.save();

      // make json file for wallet
      fs.appendFile(`./wallet/${password}.json`, JSON.stringify(privateKey), function(err, file) {
        if(err) throw err;
        console.log('Saved');
      })
      // end

      const balance = await arweave.wallets.getBalance(password); // winston

      res.json({
        status: true,
        balance: balance,
        message: savedUser
      });
    }
}

const deposit = async (req, res) => {
  // if(environment !== 'development') {
  //   return res.json({
  //     status: false,
  //     message: 'This feature works only on testnet'
  //   });
  // }
  // Validate
  const validationRule = {
    //"amount": "required|integer",
  };

  const {
    email
  } = req.user;

  
  const {
    amount,
  } = req.body;

  await validator(req.body, validationRule, {}, async (err, status) => {
    if(!status) {
      res
        .status(412)
        .send({
          status: false,
          message: 'Validation failed',
          data: err
        });
    } else {
      // get user from email
      const existUser = await User.findOne({email: email});
      if(!!existUser) {
        const walletAddress = await arweave.wallets.jwkToAddress(existUser.privateKey);

        if(environment !== 'development') {
          const {
            stdout,
            stderr,
            code
          } = await shell.exec(`npx ardrive send-ar -w ./wallet/${platformWallet}.json --dest-address ${walletAddress} --ar-amount 0.001`);

          if(code === 0) {
            const balance = await arweave.wallets.getBalance(walletAddress); // winston
            let ar = await arweave.ar.winstonToAr(balance); // winston to ar
            return res.json({
              status: true,
              results: ar
            })
          }
          
          res.json({
            status: false,
            msg: stderr
          });
        } else {
          shell.exec(`curl ${arweaveAddress}/mint/${walletAddress}/${amount}`, async (error, results) => {
            if(error) {
              res.status(400).json(error);
            }
            res.status(200).json({
              results: await arweave.ar.winstonToAr(results), // winston to ar
            })
          })
        }
      } else {
        res.json({
          status: false,
          message: 'User not found'
        });
      }
      // end
    }
  })
}

const UsersController = {
  deposit,
  register,
  getBalance,
};

export default UsersController;