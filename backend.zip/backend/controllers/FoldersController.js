import {
  readJWKFile,
  arDriveFactory,
} from 'ardrive-core-js';
import arweave from '../api';
import shell from 'shelljs';
import path, {
  resolve
} from 'path';
import {
  arweaveAddress
} from '../api'
import * as conf from '../config.json';
import User from '../models/UsersModel';
import Thumb from '../models/ThumbsModel';
import validator from '../helper/validate'

const environment = process.env.NODE_ENV || 'development';
const config = conf[environment];

const listFolder = async (req, res) => {
  // Validate
  const validationRule = {
    "parentFolderId": "required|string",
  };

  const {
    email
  } = req.user;

  const {
    parentFolderId,
    driveKey,
    type = 'public',
  } = req.body;

  if(type == 'private') {
    validationRule.driveKey = "required|string";
  }

  await validator(req.body, validationRule, {}, async (err, status) => {
    if(!status) {
      res
        .status(412)
        .send({
          status: false,
          message: 'Validation failed',
          data: err
        });
    } else {
      const existUser = await User.findOne({email: email});
      if(!!existUser) {
        const myWallet = readJWKFile(`./wallet/${existUser.password}.json`);
        const arDrive = arDriveFactory({
          wallet: myWallet,
          arweave: arweave,
        })
        let result;
        if(type === 'public') {
          const {
            stdout,
            stderr,
            code
          } = await shell.exec(`npx ardrive list-folder --parent-folder-id ${parentFolderId} --gateway ${arweaveAddress}`);
          if(code === 1)
            res.json({
              status: true,
              msg: JSON.parse(stdout.replace("\n", ""))
            })
          
          result = JSON.parse(stdout);
        } else if(type === 'private') {
          const {
            stdout,
            stderr,
            code
          } = await shell.exec(`npx ardrive list-folder --parent-folder-id ${parentFolderId} --wallet-file ./wallet/${existUser.password}.json --gateway ${arweaveAddress} --drive-key ${driveKey}`);
          if(code === 1)
            res.json({
              status: false,
              msg: stdout.replace("\n", "")
            })
          
          result = JSON.parse(stdout);
        } else {
          res.json({
            status: false,
            msg: 'You can select public or private for folder type'
          });
        }
        let idsArr = result.map(item => item.dataTxId);
        let assetUrls = await Thumb.find({
          id: {
            $in: idsArr
          }
        });
        let re_result = result.map(item => {
          var temp = item;
          assetUrls.map(i => {
            if(item.dataTxId === i.id)
              temp.url = i.url
          })
          return temp;
        })

        res.json({
          status: true,
          msg: `Successfully get ${type} folder list`,
          data: re_result,
        })
      } else {
        res.json({
          status: false,
          message: 'User not found'
        });
      }
    }
  })
  // end
  const {
    privateKey,
  } = await User.findOne({email});
  const myWallet = readJWKFile(privateKey);
  const arDrive = arDriveFactory({ wallet: myWallet });
  let createFolderResult = {};
  if(type === 'public') {
    createFolderResult = await arDrive.createPublicFolder({ folderName, parentFolderId });
  }
  if(type === 'private') {
    createFolderResult = await arDrive.createPrivateFolder({ folderName, driveKey, parentFolderId });
  }
  res.json({
    status: createFolderResult
  })
};

const createFolder = async (req, res) => {
  // Validate
  const validationRule = {
    "folderName": "required|string",
    "parentFolderId": "required|string",
  };

  const {
    email
  } = req.user;

  const {
    folderName,
    parentFolderId,
    driveKey,
    type = 'public',
  } = req.body;

  if(type === 'private') {
    validationRule['driveKey'] = 'required|string';
  }

  await validator(req.body, validationRule, {}, async (err, status) => {
    if(!status) {
      res
        .status(412)
        .send({
          status: false,
          message: 'Validation failed',
          data: err
        });
    } else {
      const existUser = await User.findOne({email: email});
      if(!!existUser) {
        const myWallet = readJWKFile(`./wallet/${existUser.password}.json`);
        const arDrive = arDriveFactory({
          wallet: myWallet,
          arweave: arweave,
        })
        let result;
        if(type === 'public') {
          const {
            stdout,
            stderr,
            code
          } = await shell.exec(`npx ardrive create-folder --parent-folder-id ${parentFolderId} --folder-name ${folderName} -w ./wallet/${existUser.password}.json --gateway ${arweaveAddress}`);
          if(code === 1)
            res.json({
              status: false,
              msg: stdout.replace("\n", "")
            })
          
        result = JSON.parse(stdout);
        } else if(type === 'private') {
          const {
            stdout,
            stderr,
            code
          } = await shell.exec(`npx ardrive create-folder --parent-folder-id ${parentFolderId} --folder-name ${folderName} -w ./wallet/${existUser.password}.json --gateway ${arweaveAddress} --drive-key ${driveKey}`);
          if(code === 1)
            res.json({
              status: false,
              msg: stdout.replace("\n", "")
            })
          
          result = JSON.parse(stdout);
        } else {
          res.json({
            status: false,
            msg: 'You can select public or private for folder type'
          });
        }
        res.json({
          status: true,
          msg: `Successfully ${type} folder created`,
          data: result
        })
      } else {
        res.json({
          status: false,
          message: 'User not found'
        });
      }
    }
  })
  // end
  const {
    privateKey,
  } = await User.findOne({email});
  const myWallet = readJWKFile(privateKey);
  const arDrive = arDriveFactory({ wallet: myWallet });
  let createFolderResult = {};
  if(type === 'public') {
    createFolderResult = await arDrive.createPublicFolder({ folderName, parentFolderId });
  }
  if(type === 'private') {
    createFolderResult = await arDrive.createPrivateFolder({ folderName, driveKey, parentFolderId });
  }
  res.json({
    status: true,
    data: createFolderResult
  })
};

const renameFolder = async (req, res) => {
  // Validate
  const validationRule = {
    "newFolderName": "required|string",
    "folderId": "required|string",
  };

  const {
    email
  } = req.user;

  const {
    newFolderName,
    folderId,
    driveKey,
    type = 'public',
  } = req.body;

  if(type === 'private') {
    validationRule.driveKey = "required|string"
  }

  await validator(req.body, validationRule, {}, async (err, status) => {
    if(!status) {
      res
        .status(412)
        .send({
          status: false,
          message: 'Validation failed',
          data: err
        });
    } else {
      const existUser = await User.findOne({email: email});
      if(!!existUser) {
        const myWallet = readJWKFile(`./wallet/${existUser.password}.json`);
        const arDrive = arDriveFactory({
          wallet: myWallet,
          arweave: arweave,
        })
        let result;
        if(type === 'public') {
          const {
            stdout,
            stderr,
            code
          } = await shell.exec(`npx ardrive rename-folder --folder-id ${folderId} --folder-name ${newFolderName} -w ./wallet/${existUser.password}.json --gateway ${arweaveAddress}`);
          if(code === 1)
            res.json({
              status: false,
              msg: stdout.replace("\n", "")
            })
          
        result = JSON.parse(stdout);
        } else if(type === 'private') {
          const {
            stdout,
            stderr,
            code
          } = await shell.exec(`npx ardrive rename-folder --folder-id ${folderId} --folder-name ${newFolderName} -w ./wallet/${existUser.password}.json --gateway ${arweaveAddress} --drive-key ${driveKey}`);
          if(code === 1)
            res.json({
              status: false,
              msg: stdout.replace("\n", "")
            })
          
          result = JSON.parse(stdout);
        } else {
          res.json({
            status: false,
            msg: 'You can select public or private for folder type'
          });
        }
        res.json({
          status: true,
          msg: `Successfully ${type} folder renamed`,
          data: result
        })
      } else {
        res.json({
          status: false,
          message: 'User not found'
        });
      }
    }
  })
  // end
  const {
    privateKey,
  } = await User.findOne({email});
  const myWallet = readJWKFile(privateKey);
  const arDrive = arDriveFactory({ wallet: myWallet });
  let createFolderResult = {};
  if(type === 'public') {
    createFolderResult = await arDrive.createPublicFolder({ folderName, parentFolderId });
  }
  if(type === 'private') {
    createFolderResult = await arDrive.createPrivateFolder({ folderName, driveKey, parentFolderId });
  }
  res.json({
    status: false,
    data: createFolderResult
  })
};

const moveFolder = async (req, res) => {
  // Validate
  const validationRule = {
    "folderId": "required|string",
    "parentFolderId": "required|string",
  };

  const {
    email
  } = req.user;

  const {
    parentFolderId,
    folderId,
    driveKey,
    type = 'public',
  } = req.body;

  if(type === 'private') {
    validationRule.driveKey = "required|string"
  }

  await validator(req.body, validationRule, {}, async (err, status) => {
    if(!status) {
      res
        .status(412)
        .send({
          status: false,
          message: 'Validation failed',
          data: err
        });
    } else {
      const existUser = await User.findOne({email: email});
      if(!!existUser) {
        const myWallet = readJWKFile(`./wallet/${existUser.password}.json`);
        const arDrive = arDriveFactory({
          wallet: myWallet,
          arweave: arweave,
        })
        let result;
        if(type === 'public') {
          const {
            stdout,
            stderr,
            code
          } = await shell.exec(`npx ardrive move-folder --folder-id ${folderId} --parent-folder-id ${parentFolderId} -w ./wallet/${existUser.password}.json --gateway ${arweaveAddress}`);
          if(code === 1)
            res.json({
              status: false,
              msg: stdout.replace("\n", "")
            })
          
        result = JSON.parse(stdout);
        } else if(type === 'private') {
          const {
            stdout,
            stderr,
            code
          } = await shell.exec(`npx ardrive move-folder --folder-id ${folderId} --parent-folder-id ${parentFolderId} -w ./wallet/${existUser.password}.json --gateway ${arweaveAddress} --drive-key ${driveKey}`);
          if(code === 1)
            res.json({
              status: false,
              msg: stdout.replace("\n", "")
            })
          
          result = JSON.parse(stdout);
        } else {
          res.json({
            status: false,
            msg: 'You can select public or private for folder type'
          });
        }
        res.json({
          status: true,
          msg: `Successfully ${type} folder moved`,
          data: result
        })
      } else {
        res.json({
          status: false,
          message: 'User not found'
        });
      }
    }
  })
  // end
  const {
    privateKey,
  } = await User.findOne({email});
  const myWallet = readJWKFile(privateKey);
  const arDrive = arDriveFactory({ wallet: myWallet });
  let createFolderResult = {};
  if(type === 'public') {
    createFolderResult = await arDrive.createPublicFolder({ folderName, parentFolderId });
  }
  if(type === 'private') {
    createFolderResult = await arDrive.createPrivateFolder({ folderName, driveKey, parentFolderId });
  }
  res.json({
    status: true,
    data: createFolderResult
  })
};

const FoldersController = {
  createFolder,
  listFolder,
  renameFolder,
  moveFolder,
};

export default FoldersController;