import {
  readJWKFile,
  arDriveFactory,
  PrivateDriveKeyData,
} from 'ardrive-core-js';
import shell from 'shelljs';
import arweave from '../api';
import {
  arweaveAddress
} from '../api'
import path, {
  resolve
} from 'path'
import * as conf from '../config.json';
import User from '../models/UsersModel';
import validator from '../helper/validate'
import { from } from 'form-data';

const environment = process.env.NODE_ENV || 'development';
const config = conf[environment];

const listDrive = async (req, res) => {
  const {
    email
  } = req.user;

  // get user from email
  const existUser = await User.findOne({email: email});
  if(!!existUser) {
    let result;
    const {
      stdout,
      stderr,
      code
    } = await shell.exec(`npx ardrive list-all-drives -w ./wallet/${existUser.password}.json --gateway ${arweaveAddress} -p ${existUser.password} ${existUser.password}`);
    if(stderr) {
      return res.json({
        status: false,
        msg: stderr
      })
    }
    result = JSON.parse(stdout)

    res.json({
      status: true,
      msg: `Get drives list`,
      data: result
    })
  } else {
    res.json({
      status: false,
      message: 'User not found'
    });
  }
  // end
};

// email, driveName, type
const createDrive = async (req, res) => {
  // Validate
  const {
    email
  } = req.user;

  const validationRule = {
    "driveName": "required|string",
  };

  const {
    driveName,
    type = 'public',
  } = req.body;

  await validator(req.body, validationRule, {}, async (err, status) => {
    if(!status) {
      res
        .status(412)
        .send({
          status: false,
          message: 'Validation failed',
          data: err
        });
    } else {
      // get user from email
      const existUser = await User.findOne({email: email});
      if(!!existUser) {
        const myWallet = readJWKFile(`./wallet/${existUser.password}.json`);
        const arDrive = arDriveFactory({
          wallet: myWallet,
          arweave: arweave,
        })
        let result;
        if(type === 'public') {
          const {
            stdout,
            stderr,
            code
          } = await shell.exec(`npx ardrive create-drive --gateway ${arweaveAddress} --wallet-file ./wallet/${existUser.password}.json --drive-name ${driveName}`);     
          if(code === 1) {
            res.json({
              status: false,
              msg: stdout.replace('\n', '')
            })
          }
          result = JSON.parse(stdout)
        } else if(type === 'private') {
          const {
            stdout,
            stderr,
            code
          } = await shell.exec(`npx ardrive create-drive --gateway ${arweaveAddress} --wallet-file ./wallet/${existUser.password}.json --drive-name ${driveName} -p ${existUser.password} ${existUser.password}`);     
          if(stderr) {
            res.json({
              status: false,
              msg: stderr
            })
          }
          result = JSON.parse(stdout)
        } else {
          res.json({
            status: false,
            msg: 'You can select public or private for drive type'
          });
        }

        res.json({
          status: true,
          msg: `Successfully ${type} drive created`,
          data: result
        })
      } else {
        res.json({
          status: false,
          message: 'User not found'
        });
      }
      // end
    }
  })
};
// npx ardrive get-drive-key -w /path/to/my/wallet.json -d "6939b9e0-cc98-42cb-bae0-5888eca78885" -P
const getDriveKey = async (req, res) => {
  // Validate
  const validationRule = {
    "driveId": "required|string",
  };

  const {
    email
  } = req.user;

  const {
    driveId,
  } = req.body;

  await validator(req.body, validationRule, {}, async (err, status) => {
    if(!status) {
      res
        .status(412)
        .send({
          status: false,
          message: 'Validation failed',
          data: err
        });
    } else {
      // get user from email
      const existUser = await User.findOne({email: email});
      if(!!existUser) {
        const myWallet = readJWKFile(`./wallet/${existUser.password}.json`);
        const arDrive = arDriveFactory({
          wallet: myWallet,
          arweave: arweave,
        })
        let result;

        const {
          stdout,
          stderr,
          code
        } = await shell.exec(`npx ardrive get-drive-key -w ./wallet/${existUser.password}.json -d ${driveId} -p ${existUser.password} ${existUser.password} --gateway ${arweaveAddress}`);     
        if(code === 1) {
          res.json({
            status: false,
            msg: stdout.replace('\n', '')
          })
        }
        result = stdout.replace('\n', '')

        res.json({
          status: true,
          msg: `Successfully get drive key`,
          data: result
        })
      } else {
        res.json({
          status: false,
          message: 'User not found'
        });
      }
      // end
    }
  })
};

const DrivesController = {
  createDrive,
  listDrive,
  getDriveKey,
};

export default DrivesController;