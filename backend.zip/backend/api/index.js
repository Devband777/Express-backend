import Arweave from 'arweave';

const environment = process.env.NODE_ENV || 'development';

const arNet = environment !== 'development' ? {} : {
  host: '127.0.0.1',
  port: 1984,
  protocol: 'http'
};
const arweave = Arweave.init(arNet);

export const arweaveAddress = environment === 'development' ? 'http://127.0.0.1:1984' : 'https://arweave.net:443';

export default arweave;

